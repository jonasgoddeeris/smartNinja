// Test application URL: https://morning-wave-19317.herokuapp.com/get-all-bitts
